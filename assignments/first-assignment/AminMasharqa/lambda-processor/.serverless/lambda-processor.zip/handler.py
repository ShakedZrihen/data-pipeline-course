import json
import logging

logging.basicConfig(level=logging.INFO)

def process_sqs_event(event, context):
    try:
        for record in event['Records']:
            body = record['body']
            try:
                data = json.loads(body)
                logging.info("Received data from SQS: %s", json.dumps(data, indent=4))
            except json.JSONDecodeError as decode_error:
                logging.error("JSON decode error: %s", str(decode_error))
                return {"statusCode": 400, "body": json.dumps("Invalid JSON format")}
        
        return {"statusCode": 200, "body": json.dumps("Data processed successfully")}
    except Exception as e:
        logging.error("Error processing SQS event: %s", str(e))
        return {"statusCode": 500, "body": json.dumps("Error processing data")}
